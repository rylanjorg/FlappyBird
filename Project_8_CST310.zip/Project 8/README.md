Project 8


By Dylan Olthoff and Rylan Casanova

Running Project8.cpp

1. Install Ubuntu
2. Install g++ and packages to get openGL working in Ubuntu
4. Compile the Project8 file by doing $g++ Project8.cpp -o test -GL -lglut -lGLU 
5. Run Project8.cpp by doing $./test
6. Click the 'f' key to jump
7. Avoid the obstacles and last as long as you can, hitting the obstacles will result in a game over

